package io.swagger.api.factories;

import io.swagger.api.GetVoteStatusApiService;
import io.swagger.api.impl.GetVoteStatusApiServiceImpl;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2019-11-30T17:46:47.852Z[GMT]")public class GetVoteStatusApiServiceFactory {
    private final static GetVoteStatusApiService service = new GetVoteStatusApiServiceImpl();

    public static GetVoteStatusApiService getGetVoteStatusApi() {
        return service;
    }
}
