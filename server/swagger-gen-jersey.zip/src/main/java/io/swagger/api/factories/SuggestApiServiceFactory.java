package io.swagger.api.factories;

import io.swagger.api.SuggestApiService;
import io.swagger.api.impl.SuggestApiServiceImpl;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2019-11-30T17:46:47.852Z[GMT]")public class SuggestApiServiceFactory {
    private final static SuggestApiService service = new SuggestApiServiceImpl();

    public static SuggestApiService getSuggestApi() {
        return service;
    }
}
